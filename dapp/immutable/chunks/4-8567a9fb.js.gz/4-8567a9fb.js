import{default as t}from"../components/pages/myresume/_page.svelte-72c68cad.js";export{t as component};
