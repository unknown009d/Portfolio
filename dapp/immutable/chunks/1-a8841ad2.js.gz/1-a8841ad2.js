import{default as t}from"../components/pages/_error.svelte-26e3c97d.js";export{t as component};
