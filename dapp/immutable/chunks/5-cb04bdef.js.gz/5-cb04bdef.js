import{default as t}from"../components/pages/projects/_page.svelte-ca34c053.js";export{t as component};
