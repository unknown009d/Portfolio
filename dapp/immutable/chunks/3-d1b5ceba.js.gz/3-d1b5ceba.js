import{default as t}from"../components/pages/aboutme/_page.svelte-2150e993.js";export{t as component};
