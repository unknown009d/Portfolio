import{default as t}from"../components/pages/_layout.svelte-65ac10de.js";export{t as component};
